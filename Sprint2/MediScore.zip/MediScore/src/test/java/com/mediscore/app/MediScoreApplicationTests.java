package com.mediscore.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediScoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
