package com.mediscore.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediScoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediScoreApplication.class, args);
	}

}
